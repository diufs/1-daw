/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicioadicional1;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class EjercicioAdicional1 {

    public static void main(String[] args) {
        int n,esp, j;
        Scanner sc = new Scanner (System.in);
        System.out.println("Introduzca un numero");
        n=sc.nextInt();
        for(int i =1; i<=n; i++){
            for(esp=n-i; esp>=1; esp--)
                System.out.print(" ");
            for (j=1; j<=i; j++)
                System.out.print(j);
            for(int k =j-2; k>=1; k--)
                 System.out.print(k);
            System.out.println("");    
        }

        
    }
}