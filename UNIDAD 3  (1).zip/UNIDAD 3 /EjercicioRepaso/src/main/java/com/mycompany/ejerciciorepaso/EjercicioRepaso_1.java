/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciorepaso;

/**
 *
 * @author ivadro2
 */
public class EjercicioRepaso_1 {

    public static void main(String[] args) {
        // Parte de arriba: 1, 3, 5, 7 asteriscos
        for (int i = 1; i <= 7; i += 2) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        // Parte de abajo: 5, 3, 1 asteriscos
        for (int i = 5; i >= 1; i -= 2) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
