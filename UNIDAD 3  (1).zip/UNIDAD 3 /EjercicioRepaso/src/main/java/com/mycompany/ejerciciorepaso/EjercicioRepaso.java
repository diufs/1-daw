/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciorepaso;

/**
 *
 * @author ivadro2
 */
public class EjercicioRepaso {

    public static void main(String[] args) {
        for (int i=1; i<=5; i++){
            for(int j=1; j<=i; j++){
                System.out.print("*");
                
            }
            System.out.println();
        }
}
}