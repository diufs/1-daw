/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicioadicional4;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class EjercicioAdicional4 {
        
       static final int DIA =24;
    public static void main(String[] args) {
        int dia1, dia2, hora1, hora2;
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor, introduzca la primera hora");
        dia1 =sc.nextInt();
        hora1 =sc.nextInt();
        
        
        
        
        
        switch(dia1){
        case 1:
        System.out.println("Dia: Lunes");
        break;
        case 2:
        System.out.println("Dia:Martes");
        break;
        case 3:
        System.out.println("Dia:Miercoles");
        break;
        case 4:
        System.out.println("Dia:Jueves");
        break;
        case 5:
        System.out.println("Dia:Viernes");
        break;
        case 6:
        System.out.println("Dia:Sabado");
        break;
        case 7:
        System.out.println("Dia:Domingo");
        break;
        default:
            System.out.println("Dia no  valido");
    }
         System.out.printf("\nHora: %d",hora1);
         System.out.println("\nPor favor, introduzca la segunda hora");
         dia2 =sc.nextInt();
         hora2 =sc.nextInt();
        
        switch(dia2){
        case 1:
        System.out.println("Dia: Lunes");
        break;
        case 2:
        System.out.println("Dia:Martes");
        break;
        case 3:
        System.out.println("Dia:Miercoles");
        break;
        case 4:
        System.out.println("Dia:Jueves");
        break;
        case 5:
        System.out.println("Dia:Viernes");
        break;
        case 6:
        System.out.println("Dia:Sabado");
        break;
        case 7:
        System.out.println("Dia:Domingo");
        break;
        default:
            System.out.println("Dia no  valido");
    }
        int calculo= DIA-hora1;
        int calculo2 = dia2-dia1;
        int calculo3 = calculo2*24;
        int calculo4= hora2+(24-hora1);
         System.out.printf("\nHora: %d",hora2);
         System.out.printf("\nEntre las %d del lunes y las %d del martes hay %d horas", hora1, hora2, calculo4);
       
}
}