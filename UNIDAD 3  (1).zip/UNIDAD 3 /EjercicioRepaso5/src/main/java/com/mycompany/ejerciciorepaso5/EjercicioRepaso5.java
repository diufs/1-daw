/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciorepaso5;

import java.util.Scanner;

public class EjercicioRepaso5 {

    public static void main(String[] args) {
        long numero;
        long divisor = 1;
        int suma = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Por favor, introduzca un numero entero positivo");
        numero = sc.nextLong();

        while (numero / divisor >= 10) {
            divisor *= 10;
        }

        System.out.print("Digitos pares: ");

        while (divisor > 0) {
            long digito = numero / divisor;
            digito = digito % 10;

            if (digito % 2 == 0) {
                System.out.print(digito + " ");
                suma += digito;
            }

            numero = numero % divisor;
            divisor /= 10;
        }

        System.out.println();
        System.out.println("Suma de los digitos pares: " + suma);

        sc.close();
    }
}
