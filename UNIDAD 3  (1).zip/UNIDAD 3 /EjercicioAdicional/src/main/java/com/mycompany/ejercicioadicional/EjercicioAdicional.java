/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicioadicional;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class EjercicioAdicional {

    public static void main(String[] args) {
       double ancho, alto;
       char bordado;
       Scanner sc = new Scanner (System.in);
       System.out.print("Introduza la altura de la bandera en cm: ");
       alto = sc.nextInt();
       System.out.print("Ahora introduzca la anchura: ");
       ancho = sc.nextInt();
       System.out.print("Quiere escudo bordado? (s/n): ");
       bordado=sc.next().charAt(0);
       double calculo = ancho*alto;
       double precio = calculo*00.01;
       double incremento = 2.50;
       double gastos= 3.25;
       double total = precio+incremento+gastos;
       double total1 = precio+gastos;
       if(bordado == 's'){
            System.out.println("Gracias. Aqui tiene el desglose de su compra");
             System.out.printf("\nBandera de %.2fcm: %.2f€", calculo, precio   );
             System.out.printf("\nCon escudo \t%.2f€",incremento);
             System.out.printf("\nGastos de envio \t%.2f€",gastos );
             System.out.printf("\nTotal \t%.2f€", total  );
             
       }else if(bordado=='n'){ 
            System.out.println("Gracias. Aqui tiene el desglose de su compra");
             System.out.printf("\nBandera de %.2fcm: \t%.2f€",calculo, precio  );
             System.out.printf("\nSin escudo");
             System.out.printf("\nGastos de envio \t%.2f€",gastos );
             System.out.printf("\nTotal \t%.2f€", total1  );
     }else{
         System.out.print("Gracias por la visita");
                 
                 
     }
         
  
       }
}
       
 /*
*/