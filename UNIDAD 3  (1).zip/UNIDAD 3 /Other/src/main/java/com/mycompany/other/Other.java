/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.other;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Other {

    public static void main(String[] args) {
        int numero;
        int n= 73;
        int intento = 6;
        Scanner sc = new Scanner (System.in);
        
       do{
           System.out.println("Mete un numero");
           numero =sc.nextInt();
           
           
       }
       while (numero==n);
               System.out.println("Acierto");
               
    }
}
