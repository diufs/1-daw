/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio20;

/**
 *
 * @author ivadro2
 */
public class Ejercicio20 {

    public static void main(String[] args) {
     // Definimos el número base para la tabla de multiplicar
        int numero = 2;
        
        // Imprimimos el encabezado requerido
        System.out.println("Tabla del " + numero);
        System.out.println("**********");
        
        // Utilizamos un bucle 'for' para iterar del 1 al 10
        for (int i = 1; i <= 10; i++) {
            
            // Realizamos la operación aritmética de multiplicación
            int resultado = numero * i;
            
            // Imprimimos cada línea de la tabla formateada
            System.out.println(numero + " x " + i + " = " + resultado);
        }
    }
}
