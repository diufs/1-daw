/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio13;

import java.util.Scanner;

/**
 *
 * @author drobe5
 * - Escribe un programa que lea por teclado dos números en coma flotante 
 * (utilizar double) y después muestra su suma. 
 */
public class Ejercicio13 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
      // Solicitar y leer el primer número
        System.out.print("Introduce el primer número (decimal): ");
        double numero = sc.nextDouble();
        
        // Solicitar y leer el segundo número
        System.out.print("Introduce el segundo número (decimal): ");
        double numero2 = sc.nextDouble();
        
        // Calcular la suma
        double suma = numero + numero2;
        
        // Mostrar el resultado concatenando con +
        System.out.println("La suma de " + numero + " y " + numero2 + " es: " + suma);
    }
}
