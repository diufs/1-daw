/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1;

/**
 *
 * @author ivadro2
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        // Declaramos la variable asignamos un valor 1000 a la variable
        int num;
        num = 1000;
        //caracteres especiales que determinarán el tipo de dato por el que se sustituirán en este caso %d es para enteros, 
        System.out.printf("El valor es %d", num);
      
    }
}
