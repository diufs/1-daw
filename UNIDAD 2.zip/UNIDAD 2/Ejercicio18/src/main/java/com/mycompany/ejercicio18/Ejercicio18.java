/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio18;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio18 {

    public static void main(String[] args) {
       final double DIAS_POR_ANO_JOVIANO = 4332.59;

        // Crear objeto Scanner para leer los datos ingresados por el usuario
        Scanner scanner = new Scanner(System.in);

        // Solicitar el ingreso de los días terrestres
        System.out.print("Ingrese el número de días terrestres: ");
        double diasTerrestres = scanner.nextDouble();

        // Realizar la conversión
        double anosJovianos = diasTerrestres / DIAS_POR_ANO_JOVIANO;
        
        System.out.printf("%f días terrestres equivalen a años jovianos.\n", diasTerrestres, anosJovianos);
    }
}
