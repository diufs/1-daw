import java.util.Scanner;

public class SecEsc 
{ public static void main(String args[]) { 
    System.out.printf("Este es un ejemplo\nde \nSecuencias de Escape"); } } 
