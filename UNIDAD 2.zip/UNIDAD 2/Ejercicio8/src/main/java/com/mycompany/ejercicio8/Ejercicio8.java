/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio8;

/**
 *
 * @author ivadro2
 */
public class Ejercicio8 {

    public static void main(String args[]) {
    System.out.println("Este es un ejemplo\nde \nSecuencias de Escape");
    }
}
