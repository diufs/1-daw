/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio9;

/**
 *
 * @author drobe
 *  Escribe un programa que declare una variable entera llamada numero. Asigna a esta variable el valor 500 y 
 *  después utilizando la sentencia printf(), mostrar por pantalla el valor de la misma obteniendo el siguiente mensaje: 
 */
public class Ejercicio9 {

    public static void main(String[] args) {
        int numero = 500;
        System.out.printf("%d es el valor de la variable numero", numero);
    }
}
