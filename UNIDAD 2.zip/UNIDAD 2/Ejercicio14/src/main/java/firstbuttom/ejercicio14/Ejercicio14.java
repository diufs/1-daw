/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio14;

import java.util.Scanner;

/**
 *
 * @author drobe
 *  Crea un programa que pida al usuario un número entero, y a 
 * continuación utilizando el operador incremento muestra el número introducido por el usuario incrementado en una unidad. 
 */
public class Ejercicio14 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // 1. Pedir el número al usuario
        System.out.print("Introduce un número entero: ");
        int i = sc.nextInt();
        
        // 2. Incrementar la variable en una unidad
        i++;
        
        // 3. Mostrar el resultado
        System.out.println("El número incrementado en 1 es: " + i);
    }
}
