/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7;

/**
 *
 * @author ivadro2
 * Repite el ejercicio anterior utilizando alguna de las secuencias de escape vistas en clase
 */
public class Ejercicio7 {

    public static void main(String[] args) {
       char c = '/';

        // Fila 1: 10 caracteres '/'
        System.out.println("" + c + c + c + c + c + c + c + c + c + c);

        // Fila 2: 2 caracteres '/', espacio intermedio y 2 caracteres '/'
        System.out.println("\t" + c + c + " " + c + c);

        // Fila 3: 9 caracteres '/'
        System.out.println("\n" + c + c + c + c + c + c + c + c + c);
    }
}
