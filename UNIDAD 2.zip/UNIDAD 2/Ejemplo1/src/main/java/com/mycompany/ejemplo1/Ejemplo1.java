/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplo1;

/**
 *
 * @author ivadro2
 */
public class Ejemplo1 {

    public static void main(String[] args) {
        int i=1;
        int j=2;
        
        j=i++;
        
        //
        
        
       j=--i;
        
        System.out.printf("\nEl Valor de i es %d", --i, j);
        System.out.printf("\nAhora el Valor de i es %d", i, j);
    }
}
