/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio19;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio19 {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce las onzas: ");
        double onzas = teclado.nextDouble();

        double copas = onzas / 6;

        System.out.println("Equivale a " + copas + " copas.");
    }
}
