/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio11;

import java.util.Scanner;

/**
 *
 * @author drobe
 *  Crea un programa nuevo, y declara la constante PI como 3.14159. A continuación, el programa 
 *  debe pedir un número entero, que será el radio de la circunferencia, y deberá mostrar el área de esa circunferencia. 
 */
public class Ejercicio11 {

    public static void main(String[] args) {
        // Declaración de la constante PI
        final double PI = 3.14159;
        
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar el radio al usuario
        System.out.print("Introduce el radio de la circunferencia (número entero): ");
        int radio = scanner.nextInt();
        
        // Cálculo del área: PI * radio^2
        double area = PI * (radio * radio);
        
        // Mostrar el resultado con 2 decimales
        System.out.printf("El área de la circunferencia con radio %d es: %.2f%n", radio, area);     
  
    }
}