/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repaso;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Repaso {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.print("Hello World!");
        System.out.printf("\nHelloWorld");
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero");
       
        int num = sc.nextInt();
        System.out.printf("\nRu numero es %d,", num);
        
    }
}
