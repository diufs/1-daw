/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario un número entero largo y a continuación muestre por
   pantalla el siguiente mensaje: “El número introducido es X”, donde X es el número introducido
   por el usuario
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor introduce el número");
        long x = sc.nextLong();
        System.out.printf("Tu numero es %d,", x);
    }
}
