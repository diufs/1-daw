/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio16;

import java.util.Scanner;

/**
 *
 * @author drobe
 * Escribe un programa que calcule el volumen de un cubo. Haz que el programa pida al usuario cada dimensión. 
 */
public class Ejercicio16 {

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);

        // 1. Solicitar cada dimensión al usuario
        System.out.print("Introduce el ancho: ");
        double ancho = sc.nextDouble();

        System.out.print("Introduce el alto: ");
        double alto = sc.nextDouble();

        System.out.print("Introduce la profundidad: ");
        double profundidad = sc.nextDouble();

        // 2. Calcular el volumen
        double volumen = ancho * alto * profundidad;

        // 3. Mostrar el resultado
        System.out.printf("El volumen de la figura es: %f\n", volumen);
    }
}
