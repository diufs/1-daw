/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio10;

/**
 *
 * @author drobe
 * Crea un programa nuevo y declara las dos constantes siguientes. A continuación, utilizando estas constantes,
 * muestra un mensaje indicando el número de días laborales de una semana y la cantidad de días que tiene una semana
 */
public class Ejercicio10 {

static final int DIAS_SEMANA = 7; 
static final int DIAS_LABORABLES = 5;

    public static void main(String[] args) {
        System.out.println("Los dias de una semana son" + " " + DIAS_SEMANA );
        System.out.println("Los dia laborables son" + " " + DIAS_LABORABLES );
    }
}
