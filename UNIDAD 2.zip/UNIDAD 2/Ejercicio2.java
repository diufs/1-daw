/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

/**
 *
 * @author ivadro2
 */
public class Ejercicio2 {

    public static void main(String[] args) {
       
        //Declaramos las variables
       double d;
       char c;
       float f;
       //Asignamos el valor
       f=1000.521f;
       d = 500.123;
       c = 'Y';
       
       //Imprimimos con printf caracteres especiales que determinarán el tipo de dato por el que se sustituirán en este caso %f es para decimales y %c para caracteres
       System.out.printf(" f es %f", f);
       System.out.printf(" d es %f", d);
       System.out.printf(" c es %c", c);
    }
}
