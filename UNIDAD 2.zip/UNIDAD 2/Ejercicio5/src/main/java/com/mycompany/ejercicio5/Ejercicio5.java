/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio5;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario un carácter y a continuación muestre por pantalla el
   siguiente mensaje: “El carácter introducido es C”, donde C es el carácter introducido por el
   usuario desde el teclado.
 */
public class Ejercicio5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor introduce el caracter");
        char x = sc.next().charAt(0);
        System.out.printf("Tu caracter es %c,", x);
    }
}
