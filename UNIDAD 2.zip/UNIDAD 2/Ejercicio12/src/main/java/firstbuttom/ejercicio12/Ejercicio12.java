/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package firstbuttom.ejercicio12;

import java.util.Scanner;

/**
 *
 * @author drobe
 * -Crea un programa que pida al usuario un número entero, 
 * y a continuación muestre el resto de la división de ese número entre 3.
 */
public class Ejercicio12 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar el número al usuario
        System.out.print("Introduce un número entero: ");
        int numero = scanner.nextInt();

        // Calcular el resto de la división entre 3
        int resto = numero % 3;

        // Mostrar el resultado
        System.out.printf("El resto de dividir %d entre 3 es: %d5", numero, resto);
    }
}
