/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio17;

/**
 *
 * @author ivadro2
 */
public class Ejercicio17 {

    public static void main(String[] args) {
       // Constantes de conversión
        final int DIAS_ANO = 365;
        final int HORAS_DIA = 24;
        final int MINUTOS_HORA = 60;
        final int SEGUNDOS_MINUTO = 60;

        // Cálculo de segundos en un año estándar (365 días)
        long segundosAnoEstandar = (long) DIAS_ANO * HORAS_DIA * MINUTOS_HORA * SEGUNDOS_MINUTO;

        // Mostrar resultados
        System.out.printf("Segundos en un año común (365 días): %d segundos.\n", segundosAnoEstandar);
    }
}