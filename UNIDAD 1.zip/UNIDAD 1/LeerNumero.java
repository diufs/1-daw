/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leernumero;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class LeerNumero {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int texto;
        System.out.println("Por favor introduce un numero numero");
        texto =sc.nextInt();
        
    }
}
