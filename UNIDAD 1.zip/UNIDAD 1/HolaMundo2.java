/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.holamundo2;

/**
 *
 * @author ivadro2
 */
public class HolaMundo2 {

    public static void main(String[] args) {
        System.out.print("Hola Mundo 2");
    }
}
