/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.holamundo3;

/**
 *
 * @author ivadro2
 */
public class HolaMundo3 {

    public static void main(String[] args) {
        System.out.printf("Hola Mundo 3");
    }
}
