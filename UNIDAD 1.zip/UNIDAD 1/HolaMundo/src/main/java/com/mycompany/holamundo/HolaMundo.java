/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.holamundo;

/**
 *
 * @author ivadro2
 */
public class HolaMundo {

    public static void main(String[] args) {
        System.out.println("Hola Mundo con Java!");
    }
}
