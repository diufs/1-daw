/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leerdosnumeros;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class LeerDosNumeros {

    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner(System.in);
        int texto;
        int numero;
        System.out.print("Por favor introduce un numero positivo: ");
        texto =sc.nextInt();
        System.out.print("\nPor favor introduce otro numero positivo: ");
        numero =sc.nextInt();
    }
}
