/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leerletra;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class LeerLetra {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char letra;
        
        System.out.println("Por favor introduce una letra");
        letra = sc.next().charAt(0);
    }
}
