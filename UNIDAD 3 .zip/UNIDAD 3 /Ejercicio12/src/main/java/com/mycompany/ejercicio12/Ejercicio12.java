/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio12;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio12 {

    public static void main(String[] args) {
        // Creamos el objeto Scanner para leer la entrada del usuario
        Scanner sc = new Scanner(System.in);
        
        // Declaramos la variable donde guardaremos la contraseña introducida
        int contrasena;
        
        // Creamos un bucle "do-while" para que pida la contraseña AL MENOS una vez
        do {
            // Pedimos al usuario que introduzca su contraseña
            System.out.println("Introduce tu contraseña:");
            
            // Leemos el número introducido por el usuario
            contrasena = sc.nextInt();
            
            // Comprobamos si la contraseña introducida es incorrecta
            if (contrasena != 1234) {
                System.out.println("Contraseña incorrecta, inténtalo de nuevo.");
            }
            
        } while (contrasena != 1234); 
        // El bucle se repite mientras la contraseña no sea 1234
        
        // Cuando el usuario acierta la contraseña, salimos del bucle y mostramos este mensaje
        System.out.println("Contraseña correcta. ¡Bienvenido!");
    }
}
