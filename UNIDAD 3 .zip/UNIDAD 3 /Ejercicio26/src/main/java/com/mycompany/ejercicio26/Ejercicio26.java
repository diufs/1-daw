/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio26;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 *
26.- Diseñar un programa para la caja de un supermercado que lea un precio desde el
teclado y una cantidad y obtenga en la pantalla el número mínimo de monedas de 1 €,
50cts, 20cts, 10 cts, 5 cts y 1 céntimo que se deben dar de cambio
 */
public class Ejercicio26 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Precio en centimos");
        int precio =sc.nextInt();
        System.out.println("Cantidad entregada en centimos");
        int entregado = sc.nextInt();
        
        int cambio =entregado-precio;
        System.out.println("1 euro: " + cambio / 100);
        cambio = cambio % 100;

        System.out.println("50 cts: " + cambio / 50);
        cambio = cambio % 50;

        System.out.println("20 cts: " + cambio / 20);
        cambio = cambio % 20;

        System.out.println("10 cts: " + cambio / 10);
        cambio = cambio % 10;

        System.out.println("5 cts: " + cambio / 5);
        cambio = cambio % 5;

        System.out.println("1 cts: " + cambio);
    }
}
        
