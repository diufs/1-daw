/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio23;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio23 {

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Cuantos numeros");
       int n = sc.nextInt();
       
       double suma = 0;
       for(int i=1; i<=n; i++){
           System.out.println("Numero" + i+ ":");
          suma = suma +sc.nextDouble();
        }
       double media = suma/n;
        System.out.println("El valor medio es" +media);
    }
}
