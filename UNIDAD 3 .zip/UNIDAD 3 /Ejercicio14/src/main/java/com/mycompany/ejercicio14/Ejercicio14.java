/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio14;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario su usuario (número entero) y su contraseña
   (también número entero), el programa no terminará hasta que el usuario introduzca
   como código 1313 y como contraseña 4321
 */
public class Ejercicio14 {

    public static void main(String[] args) {
        // Creamos el objeto Scanner que leerá lo que escriba el usuario
        Scanner sc = new Scanner(System.in);
 
        // Variables donde guardaremos los datos introducidos
        int usuario, contrasena;
 
        // Usamos do-while porque los datos deben pedirse al menos una vez
        do {
            // Pedimos y leemos el usuario
            System.out.print("Introduce tu usuario: ");
            usuario = sc.nextInt();
 
            // Pedimos y leemos la contraseña
            System.out.print("Introduce tu contraseña: ");
            contrasena = sc.nextInt();
 
            // Si alguno de los dos datos no coincide, avisamos del error
            if (usuario != 1313 || contrasena != 4321) {
                System.out.println("Usuario o contraseña incorrectos. Inténtalo de nuevo.\n");
            }
 
        // El bucle se repite mientras el usuario O la contraseña sean incorrectos
        } while (usuario != 1313 || contrasena != 4321);
 
        // Si llegamos aquí, ambos datos son correctos
        System.out.println("Acceso concedido. ¡Bienvenido!");

    }
}
