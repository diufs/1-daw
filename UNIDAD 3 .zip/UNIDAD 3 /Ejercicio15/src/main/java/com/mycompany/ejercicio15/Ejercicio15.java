/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio15;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario un número entre 1 y 50. El programa debe
   mostrar tantas letras A como indique ese número, se debe usar break para terminar.
 */
public class Ejercicio15 {

    public static void main(String[] args) {
        // Creamos el objeto Scanner que leerá lo que escriba el usuario
        Scanner sc = new Scanner(System.in);
 
        // Pedimos el número
        System.out.print("Introduce un número entre 1 y 50: ");
        int numero = sc.nextInt();
 
        // Mientras el número esté fuera del rango, lo volvemos a pedir
        while (numero < 1 || numero > 50) {
            System.out.print("Error. Introduce un número entre 1 y 50: ");
            numero = sc.nextInt();
        }
 
        // Contador de letras A mostradas
        int contador = 0;
 
        // Bucle infinito: solo termina cuando se ejecuta el break
        while (true) {
            System.out.print("A");   // mostramos una A
            contador++;              // sumamos 1 al contador
 
            // Cuando hemos mostrado tantas A como indica el número, salimos del bucle
            if (contador == numero) {
                break;
            }
        }
 
        // Salto de línea final para que la salida quede ordenada
        System.out.println();
    }
}
