/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario su edad y diga si es mayor de edad.
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        int edad = 15;
        if (edad >=18)
        System.out.println("Mayor de edad");
        else {
            System.out.println("Menor de edad");
        }
    }
}
