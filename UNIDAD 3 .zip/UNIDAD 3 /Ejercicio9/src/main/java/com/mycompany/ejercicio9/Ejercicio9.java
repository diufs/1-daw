/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio9;

/**
 *
 * @author ivadro2
 * Crea un programa que muestre los primeros 5 números impares utilizando un
   bucle.
 */
public class Ejercicio9 {

    public static void main(String[] args) {
        //Creamos el contador y declaramos la variable
        int contador = 0;
        int num = 1;
        //Creamos el bucle mientras con funcion contador con 5 impresiones.   
        while (contador < 5) {
            System.out.println("El número " + num + " es IMPAR.");
            // Incrementamos "num" en 2 para obtener el siguiente número impar
            num = num+2;
            contador++;
        }
    }
}