/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio11;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Escribe un programa que, dado un número, muestre cada uno de sus dígitos por
pantalla, uno por línea, de derecha a izquierda (solo con operaciones aritméticas: % y
/).
 */
public class Ejercicio11 {

    public static void main(String[] args) {
    // Leemos los datos
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        int numero = sc.nextInt();

        
        //Creamos la condicion si numero es mayor que 0
        if (numero < 0) {
            numero = -numero; // trabajamos con el valor absoluto
        }
        //Creamos la comparación para comprobar si el número introducido es 0
        if (numero == 0) {
            // Si es 0, simplemente mostramos 0
            System.out.println(0);
        } else {
            // Si no es 0, entramos en un bucle que se repite mientras "numero" sea mayor que 0
            while (numero > 0) {
                // Mostramos el último dígito del número (resto de dividir entre 10
                System.out.println(numero % 10);
                // Eliminamos el último dígito dividiendo el número entre 10 (división entera)
                numero = numero / 10;
            }
        }
    }
}

        
