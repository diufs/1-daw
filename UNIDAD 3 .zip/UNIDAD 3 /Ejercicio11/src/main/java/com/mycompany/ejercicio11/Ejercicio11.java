/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio11;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Escribe un programa que, dado un número, muestre cada uno de sus dígitos por
pantalla, uno por línea, de derecha a izquierda (solo con operaciones aritméticas: % y
/).
 */
public class Ejercicio11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        int numero = sc.nextInt();

        if (numero < 0) {
            numero = -numero; // trabajamos con el valor absoluto
        }

        if (numero == 0) {
            System.out.println(0);
        } else {
            while (numero > 0) {
                System.out.println(numero % 10);
                numero = numero / 10;
            }
        }
    }
}

        
