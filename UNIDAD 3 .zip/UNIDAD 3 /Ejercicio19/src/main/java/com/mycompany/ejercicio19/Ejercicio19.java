/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio19;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que dé al usuario la oportunidad de adivinar un número entre 1
   y 100, en un máximo de 6 intentos. En cada pasada se debe avisar si se ha pasado o se
ha quedado corto.
 */
public class Ejercicio19 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int numeroSecreto = (int) (Math.random() * 100) + 1;
        int intento;
        boolean acertado = false;

        System.out.println("Adivina el número entre 1 y 100.");
        System.out.println("Tienes un máximo de 6 intentos.");

        for (int i = 1; i <= 6; i++) {
            System.out.print("Intento " + i + ": ");
            intento = sc.nextInt();

            if (intento == numeroSecreto) {
                System.out.println("¡Correcto! Has acertado el número.");
                acertado = true;
                break;
            } else if (intento < numeroSecreto) {
                System.out.println("Te has quedado corto.");
            } else {
                System.out.println("Te has pasado.");
            }
        }

        if (!acertado) {
            System.out.println("Has agotado los 6 intentos.");
            System.out.println("El número era: " + numeroSecreto);
        }
    }
}
