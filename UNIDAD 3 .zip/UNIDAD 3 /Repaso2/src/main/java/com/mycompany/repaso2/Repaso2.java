/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repaso2;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Repaso2 {

    public static void main(String[] args) {
        //ASI SE HACEN LOS MENUS 
        int num;
        do{
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero [1-6];");
        num =sc.nextInt();
        if(num<1 || num >6)
                System.out.println("Debes introducir un numero entre 1-6 ambos incluidos,Vuelve a intentarlo");
       }while(num<1 || num >6);
        System.out.println("OK");
}    
}
        
        /*for(int i =1; i<10; i++){
            System.out.println(i);
        }
        
   }
}    */
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        /* TERCER EJERCICIO
        
       Scanner sc = new Scanner (System.in);
        System.out.println("Introducir una letra");
        char letra = sc.next().charAt(0);
        if (letra == 'a' || letra =='e'|| letra =='i' ||letra =='o' || letra =='u'){
        System.out.println("Escribir una vocal");
    }else{
            System.out.println("No es una vocal");
    }
        
                 }
      }
   */
        
        /* SEGUNDO EJERCICIO 
       Scanner sc = new Scanner(System.in);
       System.out.println("Introducir edad");
       int edad = sc.nextInt();
       if (edad>18){
           System.out.println("Mayor de edad");
       }else{
           System.out.println("Menor de edad");
       }
       }
       */

        
        
        
        
        
        
        
        /* SEGUNDO EJERCICIO 
       Scanner sc = new Scanner (System.in);
        System.out.println("Introducir un numero");
        int n = sc.nextInt();
        if(n>0){
            System.out.println("Escribir Positivo");
        }else{
            System.out.println("Escribir negativo");
            
        }
        
     }
}       
       */  
        
        /* PRIMER EJERCICIO 
        Scanner sc = new Scanner (System.in);
        System.out.println("Introducir un numero");
        int n = sc.nextInt();
        
        
        if (n %2==0){
        System.out.println("El numero es par");
        }else{
        System.out.println(" El numero es impar");
        }
    }
}
        */

/*WHILE
int i = 1;

while (i <= 5) {
    System.out.println("Итерация: " + i);
    i++;
}


/* WHILE DO

/*int j = 1;

do {
    System.out.println("Итерация: " + j);
    j++;
} while (j <= 5);
*/