/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bienvenida;

/**
 *
 * @author ivadro2
 */
public class Bienvenida {

    public static void main(String[] args) {
         for(int num=10; num>=1; num--){
            //Excepcion para no mostrar el tres y continua si queremos parar usamos la palabra break
            if(num == 3)
                continue;
        System.out.println(num);
        
    }
        
  }
    }        
            
        
        
        /*DO WHILE Se ejecuta siempre
        do{
            System.out.println(num);
            num--;
        }while(num>=1);
        
        
   }
    }      
       */
        
        
        
        /*WHILE Solo se ejectuta solo si se cumple la condicion
        while(num >=1){
            System.out.println(num--);
        }
        
 }
    }
    */
        
        
     /*SWITCH CON FLECHA
     int num = 2;
     switch (num){
         case 1, 2, 3 -> {
             System.out.println("El valor es 1, o 2 o 3");
             }
         case 4 -> System.out.println("El valor es 4 "); 
         case 5 -> System.out.println("El valor es 5 "); 
         default ->System.out.println("Cualquier otro valor");
             
     }
    }
}
        
*/        
        
        
        
    /*EJERCICIO NUMERO 3 SWITCH    
    int num = 2;
     switch (num){
         case 1:
             System.out.println("El valor es 1 ");
             break;
         case 2:
             System.out.println("El valor es 2 ");
             break;
         case 3:
             System.out.println("El valor es 3 ");
             break;
         default:
             System.out.println("Cualquier otro valor");
             
     }
    }
}
      */  
        
        
        
        
        
        /*EJERCICIO NUMERO 2
           int nota = 7;
        
        if(nota <=9){
        System.out.println("SOBRESALIENTE");
        }
        else if(nota<=7){
            System.out.println("NOTABLE");
        }
        else if (nota<=6){
            System.out.println("BIEN");
        }
        else if (nota<=5){
            System.out.println("APROBADO");
        }
        else
            System.out.println("SUSPENSO");
    }
}
       */ 
        
        
        
        
        
        
        
        
        
        
        
         /*EJERCICIO NUMERO 1
        int nota = 3;
        if(nota<5){
            System.out.println("SUSPENSO");
        }
        else if(nota<6){
            System.out.println("APROBADO");
        }
        else if(nota<7){
            System.out.println("BIEN");
        }
        else if(nota<9){
            System.out.println("NOTABLE");
        }
        else{
            System.out.println("SOBRESALIENTE");
        }
        }
    }  */
      
        
        /*EJERCICIO NUMERO 1
        int edad=17;
        if(edad>=18){
        System.out.println("Eres mayor de edad");
        System.out.println("Ya puedes conducir un coche");
        }
        else{
            System.out.println("Eres menor de edad");
        }
        if(edad>=18)
            System.out.println("Eres mayor de edad");
        else
            System.out.println("Eres menor de edad");
        
        String mensaje =(edad >=18) ? "Eres mayor de edad":"Eres menor de edad";
   }
}
*/