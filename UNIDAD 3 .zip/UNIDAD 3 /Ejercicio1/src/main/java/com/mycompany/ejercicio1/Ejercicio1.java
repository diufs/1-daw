/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Ingresa un número entero: ");
        int num = sc.nextInt();
        
        // Si el resto de dividir num entre 2 es 0, el número es par
        if (num % 2 == 0) {
            System.out.println("El número " + num + " es PAR.");
        } else {
            System.out.println("El número " + num + " es IMPAR.");
        }
    }
}
