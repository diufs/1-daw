/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio16;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario un número entre 1 y 50. El programa debe
mostrar todos los números entre 1 y 50 exceptuando el indicado por el usuario. Utiliza
continue para evitar ese número.
 */
public class Ejercicio16 {

    public static void main(String[] args) {
        // Creamos el objeto Scanner que leerá lo que escriba el usuario
        Scanner sc = new Scanner(System.in);
 
        // Pedimos el número
        System.out.print("Introduce un número entre 1 y 50: ");
        int numero = sc.nextInt();
 
        // Mientras el número esté fuera del rango, lo volvemos a pedir
        while (numero < 1 || numero > 50) {
            System.out.print("Error. Introduce un número entre 1 y 50: ");
            numero = sc.nextInt();
        }
 
        // Recorremos todos los números del 1 al 50
        for (int i = 1; i <= 50; i++) {
 
            // Si es el número del usuario, continue salta a la siguiente vuelta
            // sin ejecutar el println, así que ese número no se muestra
            if (i == numero) {
                continue;
            }
 
            // Mostramos el número actual
            System.out.println(i);
        }

 
    }
}
