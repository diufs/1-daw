/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio10;

/**
 *
 * @author ivadro2
 * Crea un programa que calcule la suma de los números pares del 1 al 30 utilizando
un bucle.
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        //Declaramos la varible suma
        int suma = 0;
        //Creamos el bucle for que v incrementando valor hasta llegar a 30
        for (int i = 1; i <= 30; i++) {
            
            
            // Obtenemos el resto (módulo) de dividir "i" entre 2, para comprobar si es par
            if (i % 2 == 0) {
            // Si el resto es 0, "i" es par, así que lo sumamos al acumulador "suma"
            suma = suma + i;
            }
        }
        System.out.println("La suma de los pares del 1 al 30 es: " + suma);
    }
}

