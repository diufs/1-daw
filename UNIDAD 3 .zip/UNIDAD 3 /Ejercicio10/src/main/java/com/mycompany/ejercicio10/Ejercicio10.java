/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio10;

/**
 *
 * @author ivadro2
 * Crea un programa que calcule la suma de los números pares del 1 al 30 utilizando
un bucle.
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        int suma = 0;
        for (int i = 1; i <= 30; i++) {
            if (i % 2 == 0) {
                suma = suma +i;
            }
        }
        System.out.println("La suma de los pares del 1 al 30 es: " + suma);
    }
}

