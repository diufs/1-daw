/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7;

/**
 *
 * @author ivadro2
 * Crea un programa que muestre por pantalla los números del 1 al 10. Utiliza los 3
   tipos de bucles vistos en clase.
 */
public class Ejercicio7 {

    public static void main(String[] args) {    
       // Bucle FOR
        System.out.println("--- FOR ---");
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }

        // Bucle WHILE
        System.out.println("--- WHILE ---");
        int i = 1;
        while (i <= 10) {
            System.out.println(i);
            i++;
        }

        // Bucle DO-WHILE
        System.out.println("--- DO-WHILE ---");
        int j = 1;
        do {
            System.out.println(j);
            j++;
        } while (j <= 10);
    }
}
