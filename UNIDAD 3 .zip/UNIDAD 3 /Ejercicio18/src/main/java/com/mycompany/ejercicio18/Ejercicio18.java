/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio18;

/**
 *
 * @author ivadro2
 * Realiza un programa que muestre las tablas de multiplicar de la siguiente forma:
Tabla del 1
**********
1 x 1 = 1
Tabla del 2
**********
2 x 1 = 2
2 x 2 = 4
 */
public class Ejercicio18 {

    public static void main(String[] args) {
         // Bucle exterior: recorre las tablas (del 1 al 10)
        for (int tabla = 1; tabla <= 2; tabla++) {
 
            // Cabecera de cada tabla
            System.out.println("Tabla del " + tabla);
            System.out.println("**********");
 
            // Bucle interior: multiplica la tabla actual por los números del 1 al 10
            for (int i = 1; i <= 10; i++) {
                System.out.println(tabla + " x " + i + " = " + (tabla * i));
            }
 
            // Línea en blanco para separar una tabla de la siguiente
            System.out.println();
        }
    }
}
 