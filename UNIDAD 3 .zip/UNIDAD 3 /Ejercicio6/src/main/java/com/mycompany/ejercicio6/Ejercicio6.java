/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio6;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario dos números enteros y diga “Uno de los
   números es positivo”, “Los dos números son positivos” o bien “Ninguno de los
   números es positivo”, según corresponda
 */

public class Ejercicio6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce primer numero");
        int a = sc.nextInt();
        System.out.println("Introduce segundo numero");
        int b = sc.nextInt();
       
        if (a > 0 && b > 0) {
            System.out.println("Los dos números son positivos");
        } else if (a > 0 || b > 0) {
            System.out.println("Uno de los números es positivo");
        } else {
            System.out.println("Ninguno de los números es positivo");
        }
    }
}
