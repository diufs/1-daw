/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio17;

/**
 *
 * @author ivadro2
 * Realiza un programa utilizando bucles que muestre por pantalla la siguiente figura:
*
**
***
****
*****
 */
public class Ejercicio17 {

    public static void main(String[] args) {
        // Bucle exterior: recorre las filas (de la 1 a la 5)
        for (int fila = 1; fila <= 5; fila++) {
 
            // Bucle interior: en cada fila muestra tantos asteriscos como su número
            for (int j = 1; j <= fila; j++) {
                System.out.print("*");
            }
 
            // Al terminar la fila, saltamos a la línea siguiente
            System.out.println();
        }
    }
}

