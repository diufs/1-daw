/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio21;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Escribir un programa que calcule el número de días de un mes, dados los valores
numéricos del mes y del año
 */
public class Ejercicio21 {

    public static void main(String[] args) {
        int mes, año, dias;
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el mes");
        mes = sc.nextInt();
        System.out.println("Introduce el año");
        año = sc.nextInt();

        if (mes == 2) {
            if ((año % 4 == 0 && año % 100 != 0) || año % 400 == 0) {
                dias = 29;
            } else {
                dias = 28;
            }
        } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
            dias = 30;
        } else {
            dias = 31;
        }

        System.out.println("El mes tiene " + dias + " días");
    }
}
