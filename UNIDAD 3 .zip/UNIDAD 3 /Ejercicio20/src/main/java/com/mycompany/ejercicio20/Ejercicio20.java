/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio20;

/**
 *
 * @author ivadro2
 * - Realiza un programa utilizando bucles que muestre por pantalla la siguiente
figura:
*
***
*****
*******
*****
***
*
 */
public class Ejercicio20 {

    public static void main(String[] args) {
        // Parte superior (incluye la fila central de 7 asteriscos)
        for (int i = 1; i <= 7; i += 2) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        // Parte inferior
        for (int i = 5; i >= 1; i -= 2) {
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    }

