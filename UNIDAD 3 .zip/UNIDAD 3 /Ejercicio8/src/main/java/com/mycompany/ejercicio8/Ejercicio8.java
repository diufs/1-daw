/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio8;

/**
 *
 * @author ivadro2
 * Crea un programa que muestre por pantalla los números del 10 al 1. Utiliza los 3
   tipos de bucles vistos en clase.
 */
public class Ejercicio8 {

    public static void main(String[] args) {
        // Bucle FOR
        System.out.println("--- FOR ---");
        for (int i = 10; i >= 1; i--) {
            System.out.println(i);
        }

        // Bucle WHILE
        System.out.println("--- WHILE ---");
        int i = 10;
        while (i >= 1) {
            System.out.println(i);
            i--;
        }

        // Bucle DO-WHILE
        System.out.println("--- DO-WHILE ---");
        int j = 10;
        do {
            System.out.println(j);
            j--;
        } while (j >= 1);
    }
}
