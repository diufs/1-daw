/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero positivo o negativo");
        int num = sc.nextInt();
        if(num > 0){
            System.out.println("El número " + num + " es POSITIVO.");
    }   else
            System.out.println("El número " + num + " es NEGATIVO");
    
}
}