/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario un número y diga si es positivo o negativo
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        //EL escaner para leer los datos
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero positivo o negativo");
        int num = sc.nextInt();
        //Creamos la condicion para  comprobar si el número es mayor que 0
        if(num > 0){
            System.out.println("El número " + num + " es POSITIVO.");
    }   else
            System.out.println("El número " + num + " es NEGATIVO");
    
}
}