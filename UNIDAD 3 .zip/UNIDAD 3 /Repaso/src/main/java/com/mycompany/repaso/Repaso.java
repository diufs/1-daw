/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repaso;

/**
 *
 * @author ivadro2
 */
public class Repaso {

    public static void main(String[] args) {
      

        for(int num=10; num>=1; num--){
            //Excepcion para no mostrar el tres y continua si queremos parar usamos la palabra break
            if(num == 3)
                continue;
        System.out.println(num);
        
    }
        
  }
    }        
        
        
        
        
        /*DO WHILE
        do{
            System.out.println(num);
            num--;
        }while(num>=1);
        
        
   }
    }      
       */
        
        
        
        /*WHILE
        while(num >=1){
            System.out.println(num--);
        }
        
 }
    }
    */
