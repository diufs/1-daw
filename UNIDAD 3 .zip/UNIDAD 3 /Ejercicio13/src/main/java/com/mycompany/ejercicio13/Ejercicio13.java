/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio13;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que calcula la cantidad de cifras que tiene un número entero
   positivo introducido por el usuario
 */
public class Ejercicio13 {

    public static void main(String[] args) {
        // Creamos el objeto Scanner que leerá lo que escriba el usuario
        Scanner sc = new Scanner(System.in);
 
        // Pedimos el número. Usamos long para admitir números grandes (hasta 19 cifras)
        System.out.print("Introduce un número entero positivo: ");
        long numero = sc.nextLong();
 
        // Mientras el número no sea positivo, lo volvemos a pedir
        while (numero <= 0) {
            System.out.print("Error. Introduce un número entero positivo: ");
            numero = sc.nextLong();
        }
 
        // Contador de cifras, empieza en 0
        int cifras = 0;
 
        // En cada vuelta dividimos entre 10, lo que elimina la última cifra
        // (por ejemplo: 4532 -> 453 -> 45 -> 4 -> 0), y sumamos 1 al contador
        while (numero > 0) {
            numero /= 10;
            cifras++;
        }
 
        // Cuando el número llega a 0 ya no quedan cifras: mostramos el resultado
        System.out.println("El número tiene " + cifras + " cifras.");
    }
}
