/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio5;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario tres números, y los muestre ordenados de
menor a mayor.
 */
public class Ejercicio5 {

    public static void main(String[] args) {
         //Leemos los datos un entero para introducir una numero
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el numero a ");
        int a =sc.nextInt();
        System.out.println("Introduce el numero b ");
        int b=sc.nextInt();
        System.out.println("Introduce el numero c ");
        int c=sc.nextInt();
        
        //Creamos la condicion si con el operador lógico AND (&&)
        if (a <= b && b <= c) {
            System.out.println(a + ", " + b + ", " + c);
        } else if (a <= c && c <= b) {
            System.out.println(a + ", " + c + ", " + b);
        } else if (b <= a && a <= c) {
            System.out.println(b + ", " + a + ", " + c);
        } else if (b <= c && c <= a) {
            System.out.println(b + ", " + c + ", " + a);
        } else if (c <= a && a <= b) {
            System.out.println(c + ", " + a + ", " + b);
        } else {
            System.out.println(c + ", " + b + ", " + a);
        }
    }
}