/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 * Crea un programa que pida al usuario una letra y diga si es una vocal.
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        
        //Leemos los datos con un char para introducir una letra
        Scanner sc = new Scanner (System.in);
        System.out.println("Introduce una letra");
        char letra = sc.next().charAt(0);
        
        //Creamos la condicion si con el operador lógico OR (||)
        if (letra == 'a'|| letra =='o' ||letra =='i'|letra =='u'){
            System.out.println("Es una vocal");
        }else
            System.out.println("Es una consonante");
        
    }
}
