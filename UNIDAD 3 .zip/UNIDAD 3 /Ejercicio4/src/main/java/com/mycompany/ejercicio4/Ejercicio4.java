/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Introduce una letra");
        char letra = sc.next().charAt(0);
        if (letra == 'a'|| letra =='o'){
            System.out.println("Es una vocal");
        }else
            System.out.println("Es una consonante");
        
    }
}
