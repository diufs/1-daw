/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio9;

/**
 *
 * @author ivadro2
 */
public class Ejercicio9 {

    public static void main(String[] args) {
       for (int i=1; i<=9; i++){
           if(i%2 !=0){
        System.out.println(i);
    }
}
}
}