/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;
import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        char letra;
        Scanner sc =new Scanner(System.in);
        System.out.println("Introduce una letra");
        letra=sc.next().charAt(0);
        if(letra=='a'||letra=='o'|| letra=='u'||letra=='i'){
            System.out.printf("Es una vocal %c", letra);
    }else{
            System.out.printf("No es una vocal %c", letra);
        }
}
}
