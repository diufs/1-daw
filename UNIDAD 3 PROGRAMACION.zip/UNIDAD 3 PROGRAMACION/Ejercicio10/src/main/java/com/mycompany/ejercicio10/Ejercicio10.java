/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio10;

/**
 *
 * @author ivadro2
 */
public class Ejercicio10 {

    public static void main(String[] args) {
      int suma = 0;
        for (int i =1; i<=30; i++){
       if(i%2==0)
        suma += i;
           System.out.println(suma);
        
        
        
    }
}
}