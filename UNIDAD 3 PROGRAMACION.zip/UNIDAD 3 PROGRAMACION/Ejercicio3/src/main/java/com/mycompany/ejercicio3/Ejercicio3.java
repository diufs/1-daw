/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio3;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio3 {

    public static void main(String[] args) {
        int edad;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca edad");
        edad =sc.nextInt();
        if (edad>=18){
            System.out.printf("Eres mayor de edad %d", edad);
            
        }else{
            System.out.printf("Eres menor de edad %d", edad);
        }
    }
}
