/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio7;

/**
 *
 * @author ivadro2
 */
public class Ejercicio7 {

    public static void main(String[] args) {
     System.out.println("BUCLE WHILE");
      int numero = 1;
      while(numero<=10){
     System.out.println (numero);
      numero++;
    }
      numero =1;
      do{
          System.out.println(numero);
          numero++;
      }while(numero<=10);
      
      for(int i=1; i<=10; i++){
          System.out.println(i);
      }

}
}
