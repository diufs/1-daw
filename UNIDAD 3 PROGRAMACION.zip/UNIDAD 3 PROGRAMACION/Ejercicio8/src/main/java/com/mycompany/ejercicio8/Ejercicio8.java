/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio8;

/**
 *
 * @author ivadro2
 */
public class Ejercicio8 {

    public static void main(String[] args) {
        System.out.println("Bucle WHILE");
        int numero = 10;
        while(numero>=1){
            System.out.println(numero);
            numero--;
        }
        numero=10;
        System.out.println("Bucle DO-WHILE");
        do{
            System.out.println(numero);
            numero--;
        }while(numero>=1);
        System.out.println("FOR");
        for(int i = 10; i>=1; i--){
            System.out.println(i);
    
    }
}
}
