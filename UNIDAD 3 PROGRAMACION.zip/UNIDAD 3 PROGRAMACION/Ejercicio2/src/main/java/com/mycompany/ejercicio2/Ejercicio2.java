/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio2 {

    public static void main(String[] args) {
     int numero;
     Scanner sc = new Scanner (System.in);
     System.out.println("Introduzca un numero");
     numero = sc.nextInt();
     if(numero>0){
         System.out.printf("Numero es positivo %d", numero);
         
     }else{
         System.out.printf("Numero es negativo %d",numero);
     }
    }
}
