/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class EJercicio1 {

    public static void main(String[] args) {
       int numero;
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca un numero");
        numero=sc.nextInt();
        if(numero%2==0){
            System.out.printf("Numero es par %d", numero);
        }else{
            System.out.printf("Numero es impar %d", numero);
        }
    }
}
