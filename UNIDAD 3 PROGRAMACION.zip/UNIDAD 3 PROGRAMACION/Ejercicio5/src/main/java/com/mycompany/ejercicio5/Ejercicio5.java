/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio5;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio5 {

    public static void main(String[] args) {
        int numero1, numero2, numero3;
        Scanner sc = new Scanner(System.in);
        System.out.print("Primer numero");
        numero1=sc.nextInt();
        System.out.print("Segundo numero");
        numero2=sc.nextInt();
        System.out.print("Tercer numero");
        numero3=sc.nextInt();
        if(numero1<numero2 && numero2<numero3)
            System.out.printf("Mostrar numero de menor a mayor %d %d %d", numero1, numero2, numero3);
        
    }
}
