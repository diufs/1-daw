/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio6;

import java.util.Scanner;

/**
 *
 * @author ivadro2
 */
public class Ejercicio6 {

    public static void main(String[] args) {
        int numero1, numero2;
        Scanner sc = new Scanner(System.in);
        System.out.print("Primer numero");
        numero1=sc.nextInt();
        System.out.print("Segundo numero");
        numero2=sc.nextInt();
        if(numero1>0 && numero2>0){
            System.out.println("Los dos numeros son positivos");
        }else if (numero1>0){
        System.out.println("Numero es positivo");
        }else{
            System.out.println("Ninguno es positivo");
       
    }
}
} 
